from multiprocessing import context
from re import template
from django.shortcuts import render
from django.shortcuts import get_object_or_404, redirect, render
from django.http import HttpResponse, HttpResponseRedirect
from django.template import loader
from django.views.generic.detail import DetailView
from django.core.mail import EmailMessage
from django.template.loader import render_to_string
from django.contrib import messages
from django.conf import settings
from .models import *
from .forms import *

from django.contrib.auth import login, logout
from django.contrib.auth.forms import UserCreationForm


def indexView(request):
    template = loader.get_template('home.html')
    context = {}
    return HttpResponse(template.render(context,request))

def perfilView(request):
    template = loader.get_template('edicion_Perfil.html')
    context = {}
    return HttpResponse(template.render(context,request))


def eservicioView(request):
    template = loader.get_template('edicion_Servicio.html')
    context = {}
    return HttpResponse(template.render(context,request))

def servicios_view(request):
    servicios = Servicio.objects.all()  
    return render(request, 'servicios.html', {'servicios': servicios})


def contacto_view(request):
    if request.method == 'POST':
        form = ContactoForm(request.POST)
        if form.is_valid():
            form.save()  # Guarda los datos en la base de datos
            return redirect('success')  # Redirige a una página de éxito o a donde desees
    else:
        form = ContactoForm()
    
    return render(request, 'contacto.html', {'form': form})

# views.py
def success_view(request):
    return render(request, 'success.html')


