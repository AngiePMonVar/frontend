from unicodedata import name
from django.urls import path
from django.views import View
from django.contrib.auth.views import LoginView, LogoutView


from . import views 

urlpatterns = [
    path('', views.indexView, name='index'),
    path('edicion_perfil/', views.perfilView, name='e_perfil'),
    path('edicion_servicio/', views.eservicioView, name='e_servicios'),
    path('servicios/', views.servicios_view, name='servicios'),
    path('contacto/', views.contacto_view, name='contacto'),
    path('success/', views.success_view, name='success'),
]