from django.db import models

class Servicio(models.Model):
    nombre = models.CharField(max_length=100)
    descripcion = models.TextField()

    def get_nombre(self):
        return self.nombre

    def get_descripcion(self):
        return self.descripcion

    def __str__(self):
        texto= "{0} ({1})"
        return texto.format(self.nombre, self.id)


class Contacto(models.Model):
    nombre = models.CharField(max_length=100)
    correo = models.EmailField()
    asunto = models.CharField(max_length=200)
    mensaje = models.TextField()


    def get_nombre(self):
        return self.nombre
    
    def get_correo(self):
        return self.correo
    
    def get_asunto(self):
        return self.asunto
    
    def get_mensaje(self):
        return self.mensaje

    def __str__(self):
        return f"Mensaje de {self.nombre} - {self.correo}"